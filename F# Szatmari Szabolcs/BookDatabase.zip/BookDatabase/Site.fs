namespace BookDatabase

open WebSharper
open WebSharper.Sitelets
open WebSharper.UI
open WebSharper.UI.Server
open WebSharper.UI.Html
open WebSharper.UI.ClientServer

// Define the endpoint for routing
type EndPoint =
    | [<EndPoint "/">] Home
    | [<EndPoint "/about">] About

// Define the data structure for books
type Book = {
    Title: string
    Author: string
    YearPublished: int
}

// In-memory storage for books
let bookStore = System.Collections.Concurrent.ConcurrentBag<Book>()

// Endpoint to add a book
[<Rpc>]
let AddBook (book: Book) =
    bookStore.Add(book)

// Endpoint to fetch all books
[<Rpc>]
let GetBooks() =
    bookStore.ToArray()

// Templating for the menu bar and main content
module Templating =
    open WebSharper.UI.Html

    // Compute a menu bar where the menu item for the given endpoint is active
    let MenuBar (ctx: Context<EndPoint>) endpoint : Doc list =
        let ( => ) txt act =
            let isActive = if endpoint = act then "nav-link active" else "nav-link"
            li [attr.``class`` "nav-item"] [
                a [
                    attr.``class`` isActive
                    attr.href (ctx.Link act)
                ] [text txt]
            ]
        [
            "Home" => EndPoint.Home
            "About" => EndPoint.About
        ]

    let Main ctx action (title: string) (body: Doc list) =
        Content.Page(
            Templates.MainTemplate()
                .Title(title)
                .MenuBar(MenuBar ctx action)
                .Body(body)
                .Doc()
        )

// Client-side functionality
module Client =

    open WebSharper.UI
    open WebSharper.UI.Html
    open WebSharper.UI.ClientServer

    // Form to add a book
    let addBookForm (dispatch: Book -> unit) =
        let titleVar = Var.Create ""
        let authorVar = Var.Create ""
        let yearVar = Var.Create 0

        div [] [
            h3 [] [ text "Add a Book" ]
            input [ attr.placeholder "Title"; bind.input titleVar ] []
            input [ attr.placeholder "Author"; bind.input authorVar ] []
            input [ attr.placeholder "Year Published"; bind.inputAsInt yearVar ] []
            button [ on.click (fun _ -> 
                let book = { Title = titleVar.Value; Author = authorVar.Value; YearPublished = yearVar.Value }
                dispatch book
            ) ] [ text "Add Book" ]
        ]

    // Display all stored books
    let displayBooks () =
        GetBooks() 
        |> Array.map (fun book ->
            div [] [
                h4 [] [ text book.Title ]
                p [] [ text $"Author: {book.Author}" ]
                p [] [ text $"Year Published: {book.YearPublished}" ]
            ]
        )
        |> div []

// Site configuration
module Site =

    open WebSharper.UI.Html
    open WebSharper.UI.ClientServer

    // Home page with the book database functionality
    let HomePage ctx =
        Templating.Main ctx EndPoint.Home "Home" [
            h1 [] [ text "Book Database" ]
            div [] [
                client (Client.addBookForm (fun book -> AddBook book)) // Form to add books
            ]
            h3 [] [ text "All Stored Books" ]
            div [] [
                client (Client.displayBooks()) // Display all stored books
            ]
        ]

    let AboutPage ctx =
        Templating.Main ctx EndPoint.About "About" [
            h1 [] [ text "About" ]
            p [] [ text "This is a book database built with WebSharper." ]
        ]

    [<Website>]
    let Main =
        Application.MultiPage (fun ctx endpoint ->
            match endpoint with
            | EndPoint.Home -> HomePage ctx
            | EndPoint.About -> AboutPage ctx
        )
