namespace TaskManagementSystem

open WebSharper
open WebSharper.UI
open WebSharper.UI.Html

// Define the Task model
type Task = {
    Id: int
    Title: string
    Description: string
    Completed: bool
}

[<JavaScript>]
module Client =
    // Task list state
    let taskList = Var.Create []

    // Function to add a task
    let addTask title description =
        let newTask = {
            Id = List.length taskList.Value + 1
            Title = title
            Description = description
            Completed = false
        }
        taskList.Value <- newTask :: taskList.Value

    // Function to toggle task completion
    let toggleTaskCompletion taskId =
        taskList.Value <- taskList.Value |> List.map (fun t ->
            if t.Id = taskId then { t with Completed = not t.Completed } else t)

    // Function to delete a task
    let deleteTask taskId =
        taskList.Value <- taskList.Value |> List.filter (fun t -> t.Id <> taskId)

    // Function to edit a task
    let editTask taskId newTitle newDescription =
        taskList.Value <- taskList.Value |> List.map (fun t ->
            if t.Id = taskId then { t with Title = newTitle; Description = newDescription } else t)

    // Main UI
    let main =
        let newTaskTitle = Var.Create ""
        let newTaskDescription = Var.Create ""
        let editTaskTitle = Var.Create ""
        let editTaskDescription = Var.Create ""
        let editingTaskId = Var.Create None

        div [] [
            h1 [] [text "Task Management System"]
            div [] [
                h3 [] [text "Add a new task"]
                input [attr.placeholder "Title"; bind.value newTaskTitle]
                input [attr.placeholder "Description"; bind.value newTaskDescription]
                button [on.click (fun _ -> addTask newTaskTitle.Value newTaskDescription.Value)] [text "Add Task"]
            ]
            div [] [
                h3 [] [text "Tasks"]
                div [] [
                    forEach taskList.View (fun task ->
                        div [] [
                            span [] [text task.Title]
                            span [] [text task.Description]
                            input [
                                attr.`type` "checkbox"
                                bind.checked (Var.Create task.Completed)
                                on.change (fun _ -> toggleTaskCompletion task.Id)
                            ]
                            button [on.click (fun _ -> deleteTask task.Id)] [text "Delete"]
                            button [on.click (fun _ ->
                                editingTaskId.Value <- Some task.Id
                                editTaskTitle.Value <- task.Title
                                editTaskDescription.Value <- task.Description
                            )] [text "Edit"]
                        ])
                ]
            ]
            div [] [
                cond editingTaskId.View (function
                    | None -> empty
                    | Some id ->
                        div [] [
                            h3 [] [text "Edit Task"]
                            input [attr.placeholder "New Title"; bind.value editTaskTitle]
                            input [attr.placeholder "New Description"; bind.value editTaskDescription]
                            button [on.click (fun _ ->
                                editTask id editTaskTitle.Value editTaskDescription.Value
                                editingTaskId.Value <- None
                            )] [text "Save"]
                        ]
                )
            ]
        ]
