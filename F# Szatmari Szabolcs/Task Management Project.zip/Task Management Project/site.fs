namespace TaskManagementSystem

open WebSharper
open WebSharper.Sitelets
open WebSharper.UI

module Server =
    type EndPoint =
        | [<EndPoint "/">] Home

    let homePage ctx =
        Content.Page(
            Title = "Home",
            Body = [Client.main]
        )

    [<Website>]
    let Main =
        Application.MultiPage (fun ctx endpoint ->
            match endpoint with
            | EndPoint.Home -> homePage ctx
        )
