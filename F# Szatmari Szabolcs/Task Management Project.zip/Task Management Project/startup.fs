namespace TaskManagementSystem

open System
open WebSharper.Sitelets

module Startup =

    [<EntryPoint>]
    let main _ =
        WebSharper.Sitelets.RunServer(Server.Main, HttpRuntime.TimeoutZero, TimeSpan.FromMinutes(30.0), None)
        0
