namespace CalculatorApp

open WebSharper
open WebSharper.Sitelets
open WebSharper.UI
open WebSharper.UI.Server
open WebSharper.UI.ClientServer
open WebSharper.UI.Html
open WebSharper.UI.Next.Html

// Define the main calculator logic
module Calculator =

    // Define calculator operations
    type Operation =
        | Add
        | Subtract
        | Multiply
        | Divide
    
    // Define calculator state
    type State = {
        Display: string
        StoredValue: float option
        CurrentOperation: Operation option
        ResetDisplay: bool
    }

    // Initial state for the calculator
    let initialState = {
        Display = "0"
        StoredValue = None
        CurrentOperation = None
        ResetDisplay = true
    }

    // Handle calculator operations
    let applyOperation (state: State) (op: Operation) =
        let current = System.Double.Parse(state.Display)
        let stored = state.StoredValue |> Option.defaultValue 0.0
        
        let result =
            match state.CurrentOperation with
            | Some Add -> stored + current
            | Some Subtract -> stored - current
            | Some Multiply -> stored * current
            | Some Divide when current <> 0.0 -> stored / current
            | _ -> current
        
        { state with 
            StoredValue = Some result
            Display = result.ToString()
            CurrentOperation = Some op
            ResetDisplay = true
        }

    // Define the calculator update function
    let update (msg: string) (state: State) =
        match msg with
        | "AC" -> initialState
        | "C" -> { state with Display = "0"; ResetDisplay = true }
        | "=" -> applyOperation state (state.CurrentOperation |> Option.defaultValue Add)
        | _ ->
            let currentOp =
                match msg with
                | "+" -> Some Add
                | "-" -> Some Subtract
                | "*" -> Some Multiply
                | "/" -> Some Divide
                | _ -> None
            
            match currentOp with
            | Some op -> applyOperation state op
            | None ->
                if state.ResetDisplay then
                    { state with Display = msg; ResetDisplay = false }
                else
                    { state with Display = state.Display + msg }

    // Define the calculator view
    let view (state: State) (dispatch: string -> unit) =
        div [] [
            // Display for calculator output
            input [ Type "text"; Value state.Display; Disabled true ] []
            
            // Define calculator buttons
            div [] [
                // Number buttons (0-9)
                for i in [0..9] do
                    button [ OnClick (fun _ -> dispatch (string i)) ] [ text (string i) ]
                
                // Operation buttons
                let operations = ["+"; "-"; "*"; "/"; "="; "AC"; "C"]
                for op in operations do
                    button [ OnClick (fun _ -> dispatch op) ] [ text op ]
            ]
        ]

// Update the HomePage to include the calculator
module Site =

    let HomePage ctx =
        Templating.Main ctx EndPoint.Home "Home" [
            h1 [] [text "Simple Calculator"]
            div [] [
                // Define Elmish Program with initial state, update function, and view
                Elmish.Program.mkSimple (fun _ -> Calculator.initialState) Calculator.update Calculator.view
                |> Elmish.Program.withReactSynchronous "calculator" // Render synchronously
                |> Elmish.Program.run
            ]
        ]

    let AboutPage ctx =
        Templating.Main ctx EndPoint.About "About" [
            h1 [] [text "About"]
            p [] [text "This is a template WebSharper client-server application with a calculator."]
        ]

    [<Website>]
    let Main =
        Application.MultiPage (fun ctx endpoint ->
            match endpoint with
            | EndPoint.Home -> HomePage ctx
            | EndPoint.About -> AboutPage ctx
        )
