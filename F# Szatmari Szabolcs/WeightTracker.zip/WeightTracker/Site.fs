namespace WeightTracker

open WebSharper
open WebSharper.Sitelets
open WebSharper.UI
open WebSharper.UI.Server
open WebSharper.UI.ClientServer
open WebSharper.UI.Html
open WebSharper.UI.Next.Html
open WebSharper.Charting

// Define the endpoint for routing
type EndPoint =
    | [<EndPoint "/">] Home
    | [<EndPoint "/about">] About

// Data structure for weight records
type WeightRecord = {
    Date: System.DateTime
    Weight: float
}

// In-memory storage for weight records
let weightStore = System.Collections.Concurrent.ConcurrentBag<WeightRecord>()

// RPC endpoint to add a weight record
[<Rpc>]
let AddWeight (record: WeightRecord) =
    weightStore.Add(record)

// RPC endpoint to fetch all weight records
[<Rpc>]
let GetWeights() =
    weightStore.ToArray()

// Template for navigation and main content
module Templating =
    open WebSharper.UI.Html

    // Menu bar with active menu items based on the current endpoint
    let MenuBar (ctx: Context<EndPoint>) endpoint : Doc list =
        let ( => ) txt act =
            let isActive = if endpoint = act then "nav-link active" else "nav-link"
            li [attr.``class`` "nav-item"] [
                a [
                    attr.``class`` isActive
                    attr.href (ctx.Link act)
                ] [text txt]
            ]
        [
            "Home" => EndPoint.Home
            "About" => EndPoint.About
        ]

    let Main ctx action (title: string) (body: Doc list) =
        Content.Page(
            Templates.MainTemplate()
                .Title(title)
                .MenuBar(MenuBar ctx action)
                .Body(body)
                .Doc()
        )

// Client-side functionality for weight tracking
module Client =

    open WebSharper.UI
    open WebSharper.UI.Html
    open WebSharper.UI.ClientServer

    // Form to add a weight record
    let addWeightForm (dispatch: WeightRecord -> unit) =
        let dateVar = Var.Create(System.DateTime.Now)
        let weightVar = Var.Create 0.0

        div [] [
            h3 [] [ text "Add Weight" ]
            input [ Type "date"; bind.inputAsDate dateVar ] []
            input [ Type "number"; bind.inputAsFloat weightVar ] []
            button [ on.click (fun _ ->
                let record = { Date = dateVar.Value; Weight = weightVar.Value }
                dispatch record
            ) ] [ text "Add Weight" ]
        ]

    // Display all stored weight records
    let displayWeights () =
        let weights = GetWeights() |> Array.sortBy (fun w -> w.Date)
        let rows = weights |> Array.map (fun w ->
            tr [] [
                td [] [ text (w.Date.ToShortDateString()) ]
                td [] [ text (sprintf "%.1f" w.Weight) ]
            ]
        )
        
        table [] [
            tr [] [ th [] [ text "Date" ]; th [] [ text "Weight" ] ]
            yield! rows
        ]

    // Create a line chart for weight changes over time
    let weightChart () =
        let weights = GetWeights() |> Array.sortBy (fun w -> w.Date)
        let data = weights |> Array.map (fun w -> w.Date, w.Weight)
        
        Chart.Line(data)
        |> Chart.WithTitle "Weight Changes Over Time"
        |> Chart.WithXAxisTitle "Date"
        |> Chart.WithYAxisTitle "Weight"

// Site configuration with Home and About pages
module Site =

    open WebSharper.UI.Html
    open WebSharper.UI.ClientServer

    let HomePage ctx =
        Templating.Main ctx EndPoint.Home "Home" [
            h1 [] [ text "Weight Tracker" ]
            div [] [
                client (Client.addWeightForm (fun record -> AddWeight record)) // Add weight form
            ]
            h3 [] [ text "All Stored Weights" ]
            div [] [
                client (Client.displayWeights()) // Display stored weight records
            ]
            h3 [] [ text "Weight Chart" ]
            div [] [
                client (Client.weightChart()) // Display the weight chart
            ]
        ]

    let AboutPage ctx =
        Templating.Main ctx EndPoint.About "About" [
            h1 [] [ text "About" ]
            p [] [ text "This is a simple weight tracker application built with WebSharper." ]
        ]

    [<Website>]
    let Main =
        Application.MultiPage (fun ctx endpoint ->
            match endpoint with
            | EndPoint.Home -> HomePage ctx
            | EndPoint.About -> AboutPage ctx
        )
